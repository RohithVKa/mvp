//
//  LoginTests.swift
//  ToDoTests
//
//  Created by eCOM-vijay.m3 on 31/01/19.
//  Copyright © 2019 VijayAppleDevOrg. All rights reserved.
//

import XCTest
@testable import ToDo
class LoginTests: XCTestCase {
    var mockLoginView:LoginViewInterface?
    let tests = [
        ["result":""],
        ["userName":nil, "password":nil],
        ["userName":nil, "password":nil],
    ]
    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        super.setUp()
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        self.mockLoginView = nil
        super.tearDown()
    }
    
    func test_LoginWithEmptyUserName() {
        let expec = expectation(description: "userName:nil user name,password:0 - should show error message")
        self.mockLoginView = MockLoginViewController1(expect: expec)
        let loginPresenter = LoginPresenter(view: mockLoginView!)
        loginPresenter.tryToLogin(userName: nil, password: "0")
        wait(for: [expec], timeout: 3)
    }
    func test_LoginWithEmptyPassword() {
        let expec = expectation(description: "userName:0 user name,password:nil - should show error message")
        self.mockLoginView = MockLoginViewController2(expect: expec)
        let loginPresenter = LoginPresenter(view: mockLoginView!)
        loginPresenter.tryToLogin(userName: "0", password: nil)
        wait(for: [expec], timeout: 3)
    }
    func test_LoginWithEmptyUserNameAndPassword() {
        let expec = expectation(description: "userName:nil user name,password:nil - should show error message")
        self.mockLoginView = MockLoginViewController1(expect: expec)
        let loginPresenter = LoginPresenter(view: mockLoginView!)
        loginPresenter.tryToLogin(userName: nil, password: nil)
        wait(for: [expec], timeout: 3)
    }
    func test_LoginWithValidUserNameAndPassword() {
        let expec = expectation(description: "userName:0,password:0 - should be able to login successfully")
        self.mockLoginView = MockLoginViewController3(expect: expec)
        let loginPresenter = LoginPresenter(view: mockLoginView!)
        loginPresenter.tryToLogin(userName: "0", password: "0")
        wait(for: [expec], timeout: 3)
    }
    func test_LoginWithInvalidUserNameAndPassword() {
        let expec = expectation(description: "userName:Invalid user name,password:invalid password - should Not be able to login successfully")
        self.mockLoginView = MockLoginViewController4(expect: expec)
        let loginPresenter = LoginPresenter(view: mockLoginView!)
        loginPresenter.tryToLogin(userName: "invalid user name", password: "invalid password")
        wait(for: [expec], timeout: 3)
    }
    
    func test_LoginWithUserNameOnlyHasEmptySpaces() {
        let expec = expectation(description: "userName:spaces,password:0  - should show error message")
        self.mockLoginView = MockLoginViewController5(expect: expec)
        let loginPresenter = LoginPresenter(view: mockLoginView!)
        loginPresenter.tryToLogin(userName: "     ", password: "0")
        wait(for: [expec], timeout: 3)
    }
    func test_LoginWithPasswordOnlyHasEmptySpaces() {
        let expec = expectation(description: "userName:0,password:spaces - should show error message")
        self.mockLoginView = MockLoginViewController6(expect: expec)
        let loginPresenter = LoginPresenter(view: mockLoginView!)
        loginPresenter.tryToLogin(userName: "0", password: "              \n")
        wait(for: [expec], timeout: 3)
    }

}

class MockLoginViewController: LoginViewInterface {
    
    var expect:XCTestExpectation
    init(expect:XCTestExpectation) {
        self.expect = expect
    }
    func enterCredentials(userName: String?, password: String?) {
        
    }
    
    func showErrorMessage(message: String?) {
    }
    
    func hideErrorMessage() {
        
    }
    
    func register() {
        
    }
    
    func login(status: Bool) {
        
    }
    
    func showLoader() {
        
    }
    
    func hideLoader() {
        
    }
    
    
}

class MockLoginViewController1: MockLoginViewController {
    override func showErrorMessage(message: String?) {
        XCTAssertEqual(message, "User Name should not be Empty!")
        self.expect.fulfill()
    }
}
class MockLoginViewController2: MockLoginViewController {
    override func showErrorMessage(message: String?) {
        XCTAssertEqual(message, "Password should not be Empty!")
        self.expect.fulfill()
    }
}
class MockLoginViewController3: MockLoginViewController {
    override func login(status:Bool) {
        XCTAssertTrue(status, "Valid login credentials should allow the user to login succesfully")
        self.expect.fulfill()
    }
}
class MockLoginViewController4: MockLoginViewController {
    override func login(status:Bool) {
        XCTAssertFalse(status, "invalid login credentials should NOT allow the user to login")
        self.expect.fulfill()
    }
}
class MockLoginViewController5: MockLoginViewController {
    override func showErrorMessage(message: String?) {
        XCTAssertEqual(message, "User Name should be valid one!")
        self.expect.fulfill()
    }
}
class MockLoginViewController6: MockLoginViewController {
    override func showErrorMessage(message: String?) {
        XCTAssertEqual(message, "Password should be valid one!")
        self.expect.fulfill()
    }
}
